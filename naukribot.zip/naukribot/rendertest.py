import json
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import time
from flask import Flask, jsonify
import os
from datetime import datetime

# import geckodriver_autoinstaller

app = Flask(__name__)

# Set up logging
logging.basicConfig(filename='naukri_update.log', level=logging.INFO, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

# Load credentials from environment variables
def load_credentials():
    """Load Naukri credentials from a JSON file."""
    with open('credentials.json', 'r') as f:
        credentials = json.load(f)
    return credentials['username'], credentials['password']

# Selenium login and update logic (from your previous code)
def update_naukri_profile():
    username, password = load_credentials()

    # Automatically install geckodriver
    options = Options()
    options.headless = True  # Run in headless mode
    driver = webdriver.Firefox(options=options)

    try:
        driver.get('https://www.naukri.com/nlogin/login')
        time.sleep(5)

        email_input = driver.find_element(By.ID, 'usernameField')
        email_input.clear()
        email_input.send_keys(username)

        password_input = driver.find_element(By.ID, 'passwordField')
        password_input.clear()
        password_input.send_keys(password)
        password_input.send_keys(Keys.RETURN)
        time.sleep(10)

        driver.get('https://www.naukri.com/mnjuser/profile?id=&altresid')
        time.sleep(5)

        edit_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(@class, 'edit') and text()='editOneTheme']"))
        )
        driver.execute_script("arguments[0].click();", edit_button)

        input_field = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//textarea[@id='resumeHeadlineTxt']"))
        )

        current_value = input_field.get_attribute('value')

        current_day = datetime.now().day

        if current_day % 2 == 1:
            if not current_value.endswith("."):
                input_field.clear()
                input_field.send_keys(current_value + ".")
        else:
            if current_value.endswith("."):
                input_field.clear()
                input_field.send_keys(current_value[:-1])

        save_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@class='btn-dark-ot' and @type='submit']"))
        )
        driver.execute_script("arguments[0].click();", save_button)

        return "Profile updated successfully"
    
    except TimeoutException as e:
        logging.error(f"Error during profile update: {str(e)}")
        return f"Error: {str(e)}"
    
    finally:
        driver.quit()

# Flask route to trigger Naukri profile update
@app.route('/trigger_naukri_update', methods=['GET'])
def trigger_naukri_update():
    """Endpoint to trigger Naukri profile update."""
    result = update_naukri_profile()
    return jsonify({"status": result})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
