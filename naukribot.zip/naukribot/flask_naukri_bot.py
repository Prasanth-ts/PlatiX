from flask import Flask, jsonify
import json
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchWindowException, TimeoutException, WebDriverException
import time
from datetime import datetime
import traceback
import os

app = Flask(__name__)

# Set up logging
logging.basicConfig(filename='naukri_update.log', level=logging.INFO, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

def load_credentials():
    """Load Naukri credentials from a JSON file."""
    with open('credentials.json', 'r') as f:
        credentials = json.load(f)
    return credentials['username'], credentials['password']

def click_with_retry(driver, element, retries=1):
    """Attempts to click the element a number of times."""
    for attempt in range(retries):
        try:
            driver.execute_script("arguments[0].click();", element)
            logging.info("Clicked the element successfully.")
            return
        except Exception as e:
            logging.warning(f"Attempt {attempt + 1} failed: {e}")
            time.sleep(1)
    logging.error("Failed to click the element after several attempts.")

def scroll_to_element(driver, element):
    """Scrolls the page to the given element."""
    driver.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(1)

def login_to_naukri(driver, username, password):
    try:
        # Open the Naukri login page
        driver.get('https://www.naukri.com/nlogin/login')
        time.sleep(5)

        # Enter the email/username
        email_input = driver.find_element(By.ID, 'usernameField')
        email_input.clear()
        email_input.send_keys(username)

        # Enter the password
        password_input = driver.find_element(By.ID, 'passwordField')
        password_input.clear()
        password_input.send_keys(password)

        # Submit the login form
        password_input.send_keys(Keys.RETURN)
        time.sleep(10)

        logging.info("Login successful")

    except Exception as e:
        logging.error(f"Error during login: {e}")

def update_naukri_profile(driver):
    try:
        logging.info("Navigating to the profile update page.")
        driver.get('https://www.naukri.com/mnjuser/profile?id=&altresid')
        time.sleep(5)

        edit_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(@class, 'edit') and text()='editOneTheme']"))
        )
        scroll_to_element(driver, edit_button)
        click_with_retry(driver, edit_button)

        input_field = WebDriverWait(driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, "//textarea[@id='resumeHeadlineTxt']"))
        )
        
        current_value = input_field.get_attribute('value')
        current_day = datetime.now().day

        if current_day % 2 == 1:
            if not current_value.endswith("."):
                input_field.clear()
                input_field.send_keys(current_value + ".")
                logging.info("Added a dot to the input field.")
        else:
            if current_value.endswith("."):
                input_field.clear()
                input_field.send_keys(current_value[:-1])
                logging.info("Removed the dot from the input field.")

        time.sleep(1)
        
        save_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@class='btn-dark-ot' and @type='submit']"))
        )
        click_with_retry(driver, save_button)

        logging.info("Profile updated successfully.")
        update_resume(driver)
    except Exception as e:
        logging.error(f"Error during profile update: {str(e)}")
        logging.error(f"Full traceback: {traceback.format_exc()}")

def update_resume(driver):
    """Uploads a new resume to the profile."""
    try:
        update_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='Update resume' and contains(@class, 'dummyUpload')]"))
        )
        file_input = driver.find_element(By.XPATH, "//input[@type='file']")
        resume_file_path = os.path.abspath("Prasanthts_data_engineer.pdf")
        file_input.send_keys(resume_file_path)
        time.sleep(5)
        logging.info("Resume uploaded successfully.")
    except Exception as e:
        logging.error(f"Error during resume upload: {e}")
        logging.error(f"Full traceback: {traceback.format_exc()}")

@app.route('/trigger_naukri_update', methods=['GET'])
def trigger_naukri_update():
    """Trigger the Naukri profile update."""
    username, password = load_credentials()

    options = Options()
    options.headless = True

    driver = webdriver.Firefox(options=options)
    try:
        login_to_naukri(driver, username, password)
        update_naukri_profile(driver)
        return jsonify({'status': 'success', 'message': 'Naukri profile updated successfully'}), 200
    except Exception as e:
        logging.error(f"Error during Naukri update: {e}")
        return jsonify({'status': 'error', 'message': 'Failed to update Naukri profile'}), 500
    finally:
        driver.quit()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
