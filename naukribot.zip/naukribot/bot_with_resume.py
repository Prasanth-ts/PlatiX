import platform  # To detect the OS
import json
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchWindowException, TimeoutException, WebDriverException
import time
from datetime import datetime
import traceback
import os
from flask import Flask, jsonify

# Import pyvirtualdisplay only if running on Linux
if platform.system() == "Linux":
    from pyvirtualdisplay import Display

app = Flask(__name__)

# Set up logging
logging.basicConfig(filename='naukri_update.log', level=logging.INFO, 
                    format='%(asctime)s:%(levelname)s:%(message)s')

def load_credentials():
    """Load Naukri credentials from a JSON file."""
    with open('credentials.json', 'r') as f:
        credentials = json.load(f)
    return credentials['username'], credentials['password']

def click_with_retry(driver, element, retries=1):
    """Attempts to click the element a number of times."""
    for attempt in range(retries):
        try:
            driver.execute_script("arguments[0].click();", element)
            logging.info("Clicked the element successfully.")
            return
        except Exception as e:
            logging.warning(f"Attempt {attempt + 1} failed: {e}")
            time.sleep(1)  # Wait before the next attempt
    logging.error("Failed to click the element after several attempts.")

def scroll_to_element(driver, element):
    """Scrolls the page to the given element."""
    driver.execute_script("arguments[0].scrollIntoView(true);", element)
    time.sleep(1)  # Optional: Wait a moment to ensure scrolling is smooth

def login_to_naukri(driver, username, password):
    try:
        # Open the Naukri login page
        driver.get('https://www.naukri.com/nlogin/login')
        time.sleep(5)

        # Enter the email/username
        email_input = driver.find_element(By.ID, 'usernameField')
        email_input.clear()
        email_input.send_keys(username)

        # Enter the password
        password_input = driver.find_element(By.ID, 'passwordField')
        password_input.clear()
        password_input.send_keys(password)

        # Submit the login form
        password_input.send_keys(Keys.RETURN)
        time.sleep(10)  # Wait for login to complete

        logging.info("Login successful")

    except Exception as e:
        logging.error(f"Error during login: {e}")

def update_naukri_profile(driver):
    try:
        logging.info("Navigating to the profile update page.")
        load_profile = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, '/mnjuser/profile')]"))
        )

        load_profile.click()
        ensure_page_load_complete(driver)

        # Wait for the edit button to be visible and clickable
        edit_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(@class, 'edit') and text()='editOneTheme']"))
        )

        logging.info("Scrolling to the edit button.")
        scroll_to_element(driver, edit_button)  # Scroll into view

        # Click the edit button with retry logic
        click_with_retry(driver, edit_button)

        logging.info("Waiting for the modal to open.")
        
        # Wait for the textarea in the modal to be visible
        input_field = WebDriverWait(driver, 20).until(
            EC.visibility_of_element_located((By.XPATH, "//textarea[@id='resumeHeadlineTxt']"))
        )
        logging.info("Found the input field for resume headline.")
        
        # Get the current value of the input field
        current_value = input_field.get_attribute('value')

        # Get the current day
        current_day = datetime.now().day
        
        # Check if the day is odd or even
        if current_day % 2 == 1:  # Odd
            if not current_value.endswith("."):
                input_field.clear()
                input_field.send_keys(current_value + ".")
                logging.info("Added a dot to the input field.")
        else:  # Even
            if current_value.endswith("."):
                input_field.clear()
                input_field.send_keys(current_value[:-1])
                logging.info("Removed the dot from the input field.")

        time.sleep(1)

        logging.info("Clicking the save button to update the profile.")
        save_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@class='btn-dark-ot' and @type='submit']"))
        )
        # Click the save button with retry logic
        click_with_retry(driver, save_button)

        logging.info("Profile updated successfully.")
        
        update_resume(driver)

    except Exception as e:
        logging.error(f"Error during profile update: {str(e)}")
        logging.error(f"Full traceback: {traceback.format_exc()}")

def update_resume(driver):
    """Uploads a new resume to the profile."""
    try:
        logging.info("Finding the 'Update resume' button.")
        
        # Wait for the 'Update resume' button to be clickable
        update_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//input[@type='button' and @value='Update resume' and contains(@class, 'dummyUpload')]"))
        )

        # Locate the file input element and send the resume file path
        logging.info("Uploading the resume file.")
        file_input = driver.find_element(By.XPATH, "//input[@type='file']")
        resume_file_path = os.path.abspath("Prasanthts_data_engineer.pdf")  # Replace with the actual path of your resume
        file_input.send_keys(resume_file_path)

        # Wait for the upload process and click save/confirm if required
        time.sleep(5)  # Wait for the file to be uploaded
        logging.info("Resume uploaded successfully.")

    except Exception as e:
        logging.error(f"Error during resume upload: {e}")
        logging.error(f"Full traceback: {traceback.format_exc()}")

@app.route('/trigger_naukri_update', methods=['GET'])
def trigger_naukri_update():
    username, password = load_credentials()

    # Set up Firefox options for headless mode
    options = Options()
    options.headless = True
    options.log.level = "trace"  # Enable logging for Firefox

    # Only start a virtual display on Linux
    if platform.system() == "Linux":
        display = Display(visible=0, size=(800, 600))
        display.start()

    driver = webdriver.Firefox(options=options)

    try:
        login_to_naukri(driver, username, password)
        update_naukri_profile(driver)
        return jsonify({'status': 'success', 'message': 'Profile updated'}), 200
    except Exception as e:
        logging.error(f"Error during execution: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        driver.quit()
        if platform.system() == "Linux":
            display.stop()  # Stop the virtual display if running on Linux

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
